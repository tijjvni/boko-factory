<?php

namespace App\Http\Livewire\Config;

use Livewire\Component;

class ProductManagement extends Component
{
    public function render()
    {
        return view('livewire.config.product-management');
    }
}

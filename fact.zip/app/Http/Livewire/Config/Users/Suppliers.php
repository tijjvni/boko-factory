<?php

namespace App\Http\Livewire\Config\Users;

use Livewire\Component;

class Suppliers extends Component
{
    public function render()
    {
        return view('livewire.config.users.suppliers');
    }
}

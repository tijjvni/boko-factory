<?php

namespace App\Http\Livewire\Config\Users;

use Livewire\Component;

class Customers extends Component
{
    public function render()
    {
        return view('livewire.config.users.customers');
    }
}

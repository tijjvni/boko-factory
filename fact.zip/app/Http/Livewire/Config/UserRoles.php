<?php

namespace App\Http\Livewire\Config;

use Livewire\Component;

class UserRoles extends Component
{
    public function render()
    {
        return view('livewire.config.user-roles');
    }
}

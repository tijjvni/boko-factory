<?php

namespace App\Http\Livewire\Config;

use Livewire\Component;

class Users extends Component
{
    public function render()
    {
        return view('livewire.config.users');
    }
}

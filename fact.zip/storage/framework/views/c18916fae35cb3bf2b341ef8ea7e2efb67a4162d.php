<div  <?php echo e($attributes->merge(['class' => 'p-4 bg-gray-50 rounded-xl text-gray-800'])); ?> >
    <div class="font-bold text-2xl leading-none"><?php echo e($title); ?></div>
    <div class="mt-2">
        <?php echo e($value); ?> <span class="text-xs"><?php echo e($info); ?></span>
        <span class="float-right  text-xs text-gray-600">
            <?php echo e($slot); ?>

        </span>
    </div>

</div><?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/components/dashboard-stat-card.blade.php ENDPATH**/ ?>
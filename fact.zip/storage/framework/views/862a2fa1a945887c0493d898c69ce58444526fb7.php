<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Production')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 px-3 md:px-5 ">

            <?php switch(request()->url()):
                case (route('production.add')): ?>
                    <nav class="bg-grey-light rounded-md w-full mb-5">
                        <ol class="list-reset flex">
                            <li><a href="<?php echo e(route('dashboard')); ?>" class="text-indigo-600 hover:text-indigo-700">Home</a></li>
                            <li><span class="fa fa-chevron-right text-gray-500 mx-2"></span></li>
                            <li><a href="<?php echo e(route('production')); ?>" class="text-indigo-600 hover:text-indigo-700">Production</a></li>
                            <li><span class="fa fa-chevron-right text-gray-500 mx-2"></span></li>
                            <li class="text-gray-500">Create </li>
                        </ol>
                    </nav>
                    <?php break; ?>
                <?php default: ?>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
                        <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Production','value' => '0','info' => 'ongoing'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <i class="fa fa-tools"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Materials','value' => '4','info' => 'running low'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-yellow-5000']); ?>
                            <i class="fa fa-list"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Orders','value' => '7','info' => 'pending'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <i class="fa fa-archive"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
                    </div>                
           <?php endswitch; ?>


            <div class="mb-5">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.banner','data' => ['message' => 'New notification for production']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'New notification for production']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>                
            </div>

            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php switch(request()->url()):
                    case (route('production.add')): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('production.create', [])->html();
} elseif ($_instance->childHasBeenRendered('oKWHkgz')) {
    $componentId = $_instance->getRenderedChildComponentId('oKWHkgz');
    $componentTag = $_instance->getRenderedChildComponentTagName('oKWHkgz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oKWHkgz');
} else {
    $response = \Livewire\Livewire::mount('production.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('oKWHkgz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php break; ?>
                    <?php default: ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('production.index', [])->html();
} elseif ($_instance->childHasBeenRendered('129xSbP')) {
    $componentId = $_instance->getRenderedChildComponentId('129xSbP');
    $componentTag = $_instance->getRenderedChildComponentTagName('129xSbP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('129xSbP');
} else {
    $response = \Livewire\Livewire::mount('production.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('129xSbP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                    
               <?php endswitch; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/production.blade.php ENDPATH**/ ?>
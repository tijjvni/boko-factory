<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('VHB72A9')) {
    $componentId = $_instance->getRenderedChildComponentId('VHB72A9');
    $componentTag = $_instance->getRenderedChildComponentTagName('VHB72A9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VHB72A9');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('VHB72A9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>
<div>
    <div class="mb-5">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.users.user-roles', [])->html();
} elseif ($_instance->childHasBeenRendered('l1706621360-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1706621360-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1706621360-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1706621360-0');
} else {
    $response = \Livewire\Livewire::mount('config.users.user-roles', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1706621360-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
    </div>
    <div class="flex flex-col md:flex-row gap-5">
        <div class="flex-grow">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.users.suppliers', [])->html();
} elseif ($_instance->childHasBeenRendered('l1706621360-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1706621360-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1706621360-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1706621360-1');
} else {
    $response = \Livewire\Livewire::mount('config.users.suppliers', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1706621360-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                    
        </div>
        <div class="flex-grow">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.users.customers', [])->html();
} elseif ($_instance->childHasBeenRendered('l1706621360-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1706621360-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1706621360-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1706621360-2');
} else {
    $response = \Livewire\Livewire::mount('config.users.customers', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1706621360-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                    
        </div>
    </div>
</div>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/livewire/config/users-management.blade.php ENDPATH**/ ?>
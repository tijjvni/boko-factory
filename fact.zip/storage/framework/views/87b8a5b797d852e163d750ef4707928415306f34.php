<div>
    
    <div class="mb-5">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.user-roles', [])->html();
} elseif ($_instance->childHasBeenRendered('l58329791-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l58329791-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l58329791-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l58329791-0');
} else {
    $response = \Livewire\Livewire::mount('config.user-roles', []);
    $html = $response->html();
    $_instance->logRenderedChild('l58329791-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>        
    </div>

    <div class="flex flex-row gap-5">
        <div class="flex-grow">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.users.suppliers', [])->html();
} elseif ($_instance->childHasBeenRendered('l58329791-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l58329791-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l58329791-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l58329791-1');
} else {
    $response = \Livewire\Livewire::mount('config.users.suppliers', []);
    $html = $response->html();
    $_instance->logRenderedChild('l58329791-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                    
        </div>
        <div class="flex-grow">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('config.users.customers', [])->html();
} elseif ($_instance->childHasBeenRendered('l58329791-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l58329791-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l58329791-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l58329791-2');
} else {
    $response = \Livewire\Livewire::mount('config.users.customers', []);
    $html = $response->html();
    $_instance->logRenderedChild('l58329791-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                    
        </div>
    </div>
</div>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/livewire/config/users.blade.php ENDPATH**/ ?>
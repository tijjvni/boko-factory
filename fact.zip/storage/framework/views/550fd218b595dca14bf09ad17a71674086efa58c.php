<a href="/">
    <img  class="w-16 h-16" src="<?php echo e(asset('logo.png')); ?>">     
</a>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>
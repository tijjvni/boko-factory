<img class="w-16 h-16" src="<?php echo e(asset('logo.png')); ?>">
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Sales')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">


            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
                <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Sales','value' => 'N25,500,450','info' => 'total'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                        <select class="
      w-full
      px-3
      py-1.5
      text-base
      font-normal
      text-gray-700
      bg-white bg-clip-padding bg-no-repeat
      outline-none
      rounded
      transition
      ease-in-out
      m-0
      focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none">
                            <option value="1">Today</option>
                            <option value="2">This week</option>
                            <option value="3">This month</option>
                            <option value="3">All time</option>
                        </select>


                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Orders','value' => '3','info' => 'pending'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec = $component; } ?>
<?php $component = App\View\Components\DashboardStatCard::resolve(['title' => 'Production','value' => '1','info' => 'requested'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardStatCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <i class="fa fa-tools"></i>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec)): ?>
<?php $component = $__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec; ?>
<?php unset($__componentOriginal27e5e96b27b219a403f5720a259fa61d772643ec); ?>
<?php endif; ?>
            </div>

            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\tijani-dl\Documents\fact\resources\views/sales.blade.php ENDPATH**/ ?>